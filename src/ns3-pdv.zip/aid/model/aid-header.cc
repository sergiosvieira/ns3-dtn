/*
 * aid-header.cc
 *
 *  Created on: 31/10/2011
 *      Author: sergio
 */

#include "aid-header.h"

#define pack754_32(f) (pack754((f), 32, 8))
#define pack754_64(f) (pack754((f), 64, 11))
#define unpack754_32(i) (unpack754((i), 32, 8))
#define unpack754_64(i) (unpack754((i), 64, 11))

/* IEEE 754 pack unpack */

uint64_t pack754(long double f, unsigned bits, unsigned expbits)
{
    long double fnorm;
    int shift;
    long long sign, exp, significand;
    unsigned significandbits = bits - expbits - 1; // -1 for sign bit

    if (f == 0.0) return 0; // get this special case out of the way

    // check sign and begin normalization
    if (f < 0) { sign = 1; fnorm = -f; }
    else { sign = 0; fnorm = f; }

    // get the normalized form of f and track the exponent
    shift = 0;
    while(fnorm >= 2.0) { fnorm /= 2.0; shift++; }
    while(fnorm < 1.0) { fnorm *= 2.0; shift--; }
    fnorm = fnorm - 1.0;

    // calculate the binary form (non-float) of the significand data
    significand = fnorm * ((1LL<<significandbits) + 0.5f);

    // get the biased exponent
    exp = shift + ((1<<(expbits-1)) - 1); // shift + bias

    // return the final answer
    return (sign<<(bits-1)) | (exp<<(bits-expbits-1)) | significand;
}

long double unpack754(uint64_t i, unsigned bits, unsigned expbits)
{
    long double result;
    long long shift;
    unsigned bias;
    unsigned significandbits = bits - expbits - 1; // -1 for sign bit

    if (i == 0) return 0.0;

    // pull the significand
    result = (i&((1LL<<significandbits)-1)); // mask
    result /= (1LL<<significandbits); // convert back to float
    result += 1.0f; // add the one back on

    // deal with the exponent
    bias = (1<<(expbits-1)) - 1;
    shift = ((i>>significandbits)&((1LL<<expbits)-1)) - bias;
    while(shift > 0) { result *= 2.0; shift--; }
    while(shift < 0) { result /= 2.0; shift++; }

    // sign it
    result *= (i>>(bits-1))&1? -1.0: 1.0;

    return result;
}


namespace ns3 {

NS_OBJECT_ENSURE_REGISTERED (AIDHeader);

AIDHeader::AIDHeader() :
	m_type(0) {

}

AIDHeader::~AIDHeader() {
}

TypeId AIDHeader::GetTypeId(void) {
	static TypeId tid =
			TypeId("ns3::AIDHeader").SetParent<Header> (). AddConstructor<
					AIDHeader> ();
	return tid;
}

TypeId AIDHeader::GetInstanceTypeId(void) const {
	return GetTypeId();
}

uint32_t AIDHeader::GetSerializedSize(void) const {
	return 40;
}

void AIDHeader::Serialize(Buffer::Iterator start) const {
	start.WriteU8(m_type);

	start.WriteU64(pack754_64(m_pos.x));
	start.WriteU64(pack754_64(m_pos.y));

	start.WriteU64(pack754_64(m_vel.x));
	start.WriteU64(pack754_64(m_vel.y));
}

uint32_t AIDHeader::Deserialize(Buffer::Iterator start) {
	m_type = start.ReadU8();

	m_pos.x = unpack754_64(start.ReadU64());
	m_pos.y = unpack754_64(start.ReadU64());

	m_vel.x = unpack754_64(start.ReadU64());
	m_vel.y = unpack754_64(start.ReadU64());

	return 40;
}

void AIDHeader::Print(std::ostream &os) const {
	os << "type=" << (uint32_t) m_type;
}

void AIDHeader::SetType(uint8_t type) {
	m_type = type;
}

uint8_t AIDHeader::GetType() {
	return m_type;
}

void AIDHeader::setPos(double x, double y) {
	m_pos.x = x;
	m_pos.y = y;
}

void AIDHeader::setVel(double x, double y) {
	m_vel.x = x;
	m_vel.y = y;
}

Vector2d AIDHeader::getPos() {
	return m_pos;
}

Vector2d AIDHeader::getVel() {
	return m_vel;
}

}
