/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */

#include <sstream>
#include <algorithm>

#include "ns3/object.h"
#include "ns3/mac48-address.h"
#include "ns3/log.h"
#include "ns3/trace-source-accessor.h"

#include "bp-bundle-protocol-agent.h"
#include "bp-sdnv.h"

NS_LOG_COMPONENT_DEFINE ("BundleProtocolAgent");
namespace ns3 {
namespace bundleProtocol {

NS_OBJECT_ENSURE_REGISTERED (BundleProtocolAgent);

TypeId
BundleProtocolAgent::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::bundleProtocol::BundleProtocolAgent")
    .SetParent<Object> ()
    .AddConstructor<BundleProtocolAgent> ()
    .AddAttribute ("BundleEndpointId",
                   "Sets the default bundle endpoint id.",
                   BundleEndpointIdValue (BundleEndpointId ()),
                   MakeBundleEndpointIdAccessor (&BundleProtocolAgent::m_eid),
                   MakeBundleEndpointIdChecker ())
    .AddTraceSource ("Created", "Created a new bundle",
                     MakeTraceSourceAccessor (&BundleProtocolAgent::m_createLogger))
    .AddTraceSource ("Relayed", "A relayed message have been received.",
                     MakeTraceSourceAccessor (&BundleProtocolAgent::m_relayLogger))
    .AddTraceSource ("Delivered", "A received message have been delivered",
                     MakeTraceSourceAccessor (&BundleProtocolAgent::m_deliveryLogger))
    .AddTraceSource ("RouterDelivered", "A router message have been delivered",
                     MakeTraceSourceAccessor (&BundleProtocolAgent::m_routerDeliveryLogger))
    ;
  return tid;
}

BundleProtocolAgent::BundleProtocolAgent ()
  : m_node (),
    m_cla (),
    m_bundleRouter (),
    m_registrationManager (new RegistrationManager ())
{}


BundleProtocolAgent::BundleProtocolAgent (BundleEndpointId defaultEndpointId, 
                                          Ptr<Node> node,
                                          Ptr<ConvergenceLayerAgent> cla,
                                          Ptr<BundleRouter> bundleRouter)
  : m_node (node), 
    m_cla (cla),
    m_bundleRouter (bundleRouter),
    m_eid (defaultEndpointId),
    m_registrationManager (new RegistrationManager ())
{}

BundleProtocolAgent::~BundleProtocolAgent ()
{}

void
BundleProtocolAgent::DoDispose ()
{
  m_cla = 0;
  m_bundleRouter = 0;
  if (m_registrationManager != 0)
    {
      delete m_registrationManager;
      m_registrationManager = 0;
    }
  m_node = 0;
  Object::DoDispose ();
}

void 
BundleProtocolAgent::Init ()
{
  m_cla->SetBundleReceivedCallback (MakeCallback (&BundleProtocolAgent::BundleReceivedFromConvergenceLayer, this));
  m_cla->SetBundleSentOkCallback (MakeCallback (&BundleProtocolAgent::BundleSentOk, this));
  m_cla->SetBundleSentFailedCallback (MakeCallback (&BundleProtocolAgent::BundleSentFailed, this));
  m_cla->SetTransmissionCancelledCallback (MakeCallback (&BundleProtocolAgent::TransmissionCancelled, this));
  m_bundleRouter->SetBundleSendCallback (MakeCallback (&BundleProtocolAgent::SendBundle, this));
  m_bundleRouter->SetCancelTransmisisonCallback (MakeCallback (&BundleProtocolAgent::CancelTransmission, this));
}

void
BundleProtocolAgent::SetBundleEndpointId (BundleEndpointId eid)
{
  m_eid = eid;
}

BundleEndpointId
BundleProtocolAgent::GetBundleEndpointId () const
{
  return m_eid;
}

void
BundleProtocolAgent::SetNode (Ptr<Node> node)
{
  m_node = node;
}

Ptr<Node>
BundleProtocolAgent::GetNode () const
{
  return m_node;
}

void
BundleProtocolAgent::SetConvergenceLayer (Ptr<ConvergenceLayerAgent> cla)
{
  m_cla = cla;
}

Ptr<ConvergenceLayerAgent>
BundleProtocolAgent::GetConvergenceLayerAgent () const
{
  return m_cla;
}

void
BundleProtocolAgent::SetBundleRouter (Ptr<BundleRouter> bundleRouter)
{
  m_bundleRouter = bundleRouter;
}

Ptr<BundleRouter>
BundleProtocolAgent::GetBundleRouter () const
{
  return m_bundleRouter;
}

// 5.2 Bundle Transmission
int
BundleProtocolAgent::BundleReceivedFromApplication (Ptr<Packet> adu, const BundleEndpointId& destination, BundlePriority priority,  Time ttl, const PrimaryProcessingControlFlags& flags)
{
  NS_LOG_DEBUG ( "(" << m_node->GetId () << ") " << "BundleProtocolAgent::BundleReceivedFromApplication ");
  Ptr<Bundle> bundle = GenerateBundle (adu, destination, priority, ttl, flags);
  m_createLogger (bundle);
  if (m_bundleRouter->AcceptBundle (bundle, true))
    {
      if (bundle->IsCustodyTransferRequested ())
        {
          CustodySignalReason reason;
          if (m_bundleRouter->AcceptCustody (bundle, reason))
            {
              CustodyAcceptance (bundle);
            }
          else 
            {
              return -1;
            }
        }
   
      // Step 2:
      bundle->AddRetentionConstraint (RC_DISPATCH_PENDING);

      m_bundleRouter->InsertBundle (bundle);

      BundleForwarding (bundle);
      return 1;
    }
  else
    {
      return -1;
    }
}

void 
BundleProtocolAgent::BundleReceivedFromConvergenceLayer (Ptr<Bundle> bundle)
{
  if (!m_bundleRouter->IsRouterSpecific (bundle))
    {
      m_relayLogger (bundle);
    }
  else 
    {
      m_routerDeliveryLogger (bundle);
    }
  
  if (m_bundleRouter->AcceptBundle (bundle))
    {
      m_bundleRouter->BundleReceived (bundle);
      
      if (m_bundleRouter->IsRouterSpecific (bundle))
        {
          m_bundleRouter->ReceiveRouterSpecific (bundle);
          return;
        }
      
      NS_LOG_DEBUG ("(" << m_node->GetId () << ") " << "BundleProtocolAgent::BundleReceivedFromConvergenceLayer (" << bundle->GetPayload ()->GetSize () << ") with source eid " << bundle->GetSourceEndpoint () << " and custodian eid: " << bundle->GetCustodianEndpoint () << " and destination eid: " << bundle->GetDestinationEndpoint ());
      //cout << Simulator::Now ().GetSeconds () << " " << "(" << m_node->GetId () << ") " << "%%%%%%%%%%%%%%%%%%%%%% BundleProtocolAgent::BundleReceivedFromConvergenceLayer (" << bundle->GetPayload ()->GetSize () << ") with source eid " << bundle->GetSourceEndpoint () << " and custodian eid: " << bundle->GetCustodianEndpoint () << " and destination eid: " << bundle->GetDestinationEndpoint () << endl;
      if (bundle->IsAdministrativeRecord ())
        {
          Ptr<Packet> payload;
          uint8_t buffer[payload->GetSize ()];
          payload->CopyData (buffer,payload->GetSize ());
          AdministrativeRecord adminRecord = AdministrativeRecord::Deserialize (buffer); 
          // The other option for a administrative record is an bundle status report
          // but these are only of interest for the application?
          if (adminRecord.GetRecordType () == CUSTODY_SIGNAL)
            {
              CustodySignal custodySignal = CustodySignal::Deserialize (buffer);
              CustodySignalReception (custodySignal);
            }
          else
            {
              BundleReception (bundle);
            }
        }
      else 
        {
          BundleReception (bundle);
        }
    }
}

Ptr<Bundle>
BundleProtocolAgent::GenerateBundle (Ptr<Packet> adu, const BundleEndpointId& destination, BundlePriority priority,  Time ttl, const PrimaryProcessingControlFlags& flags)
{
  PrimaryBundleHeader primaryHeader = PrimaryBundleHeader ();
  CanonicalBundleHeader canonicalHeader = CanonicalBundleHeader (PAYLOAD_BLOCK);

  //cout << Simulator::Now ().GetSeconds () << " (" << m_node->GetId () << ") " << " BundleProtocolAgent::GenerateBundle (" << adu->GetSize () << ")" << endl;

  // Setup primary bundle header
  primaryHeader.SetProcessingControlFlags (flags);
  primaryHeader.SetPriority (priority);
  primaryHeader.SetDestinationEndpoint (destination);
  primaryHeader.SetSourceEndpoint (m_eid);
  primaryHeader.SetCustodianEndpoint (m_eid);
  primaryHeader.SetReplicationFactor (m_bundleRouter->CalculateReplicationFactor (priority));
  primaryHeader.SetCreationTimestamp (CreationTimestamp ());
  primaryHeader.SetLifetime (ttl);

  // Setup the canoncial bundle header
  canonicalHeader.SetMustBeReplicated (false);
  canonicalHeader.SetStatusReport (false);
  canonicalHeader.SetDeleteBundle (false);
  canonicalHeader.SetLastBlock (true);
  canonicalHeader.SetDiscardBlock (true);
  canonicalHeader.SetForwarded (false);
  canonicalHeader.SetContainsEid (false);
  canonicalHeader.SetBlockLength (adu->GetSize ());

  Ptr<Bundle> result = Create<Bundle> ();

  result->SetPayload (adu);
  result->SetPrimaryHeader (primaryHeader);
  result->AddCanonicalHeader (canonicalHeader);
    
  return result;
}

void
BundleProtocolAgent::GenerateCustodySignal (Ptr<Bundle> bundle, const CustodySignalReason& reason, bool status)
{}

void
BundleProtocolAgent::GenerateCustodySignal (Ptr<Bundle> bundle, bool status)
{}

void 
BundleProtocolAgent::CancelTransmission (GlobalBundleIdentifier gbid, BundleEndpointId eid)
{
  m_cla->CancelTransmission (gbid, eid);
}

void 
BundleProtocolAgent::TransmissionCancelled  (const Mac48Address& mac, GlobalBundleIdentifier gbid)
{
  m_bundleRouter->TransmissionCancelled (mac, gbid);
}

// 5.3 Bundle dispatching
void
BundleProtocolAgent::BundleDispatching (Ptr<Bundle> bundle)
{
  if (m_registrationManager->LookupLocal (bundle->GetDestinationEndpoint ()))
    {
      LocalBundleDelivery (bundle);
    }
  else
    {
      if (m_bundleRouter->InsertBundle (bundle))
        {
          if (bundle->IsCustodyTransferRequested ())
            {
              CustodyAcceptance (bundle);
            }
          BundleForwarding (bundle);
        }
    }
}

// 5.4 Bundle Forwarding
void 
BundleProtocolAgent::BundleForwarding (Ptr<Bundle> bundle)
{
  // Step 1:
  bundle->AddRetentionConstraint  (RC_FORWARDING_PENDING);
  bundle->RemoveRetentionConstraint (RC_DISPATCH_PENDING);

  // Step 2:
  CustodySignalReason reason;
  if (m_bundleRouter->IsForwardingContradicted (bundle, reason))
    {
      // Step 3:
      ForwardingContradicted (bundle, reason);
      return;
    }
  
  // Step 4:
  if (bundle->IsCustodyTransferRequested ())
    {
      CustodyRelease (bundle);
    }

  // Step 5: Is taken care of by the router.

  // Step 6: Is taken care of in the BundleSent* () functions
}

void
BundleProtocolAgent::BundleSentOk (const Mac48Address& address, GlobalBundleIdentifier gbid, bool finalDelivery)
{
  Ptr<Bundle> bundle = m_bundleRouter->GetBundle (gbid);
  if (bundle != 0)
    {
      //  Step 6: from 5.4 
      if (bundle->GetReportBundleForwarding ())
        {
          // a bundle forwarding status report should be generated
        }
    }
      
  m_bundleRouter->BundleSent (address, gbid, finalDelivery);
}

void
BundleProtocolAgent::BundleSentFailed (const Mac48Address& address, GlobalBundleIdentifier gbid)
{
  m_bundleRouter->BundleTransmissionFailed (address, gbid);
}


// 5.4.1 Forwarding Contradicted
void
BundleProtocolAgent::ForwardingContradicted (Ptr<Bundle> bundle, const CustodySignalReason& reason)
{
  // Step 1:

  // Step 2:
  if (m_bundleRouter->IsForwardingFailure (reason))
    {
      ForwardingFailed (bundle, reason);
    }
  else 
    {
      // At some future time, when forwarding is not contradicted the bpa should try again
    }
}

// 5.4.2 Forwarding Failed
void
BundleProtocolAgent::ForwardingFailed (Ptr<Bundle> bundle, const CustodySignalReason& reason)
{
  // Step 1:
  if (bundle->IsCustodyTransferRequested ())
    {
      GenerateCustodySignal (bundle, reason, false);
    }
  
  if (m_registrationManager->LookupLocal (bundle->GetDestinationEndpoint ()))
    {
      bundle->RemoveRetentionConstraint (RC_FORWARDING_PENDING);
    }
  else
    {
      BundleDeletion (bundle, reason);
    }
}

// 5.6 Bundle Reception
void
BundleProtocolAgent::BundleReception (Ptr<Bundle> bundle)
{
  if (bundle->IsCustodyTransferRequested ())
    {
      CustodySignalReason reason;
      if (!m_bundleRouter->AcceptCustody (bundle, reason))
        {
          GenerateCustodySignal (bundle, reason, false);
          return;
        }
    }

  // Step 1:
  bundle->AddRetentionConstraint (RC_DISPATCH_PENDING);
          
  // Step 2:
  if (bundle->GetReportBundleReception ())
    {
      // Generate a bundle reception status report, with reason code "No additional information"
    }
          
  // Step 3:
  BlockList canonicalBlocks = bundle->GetCanonicalHeaders ();
  BlockList::iterator block = canonicalBlocks.begin ();
  BlockList tmp;
  
  for (BlockList::iterator block = canonicalBlocks.begin (); block != canonicalBlocks.end (); ++block)
    {
      if (!CanProcessBlock (block->GetBlockType ())) // if the bpa cannot process/understand the extension block type
        {
          if (block->IsStatusReport ())
            {
              //  reception status report with reason code "Block unintelligible"
              //  should be generated
            }
                  
          if (block->IsDeleteBundle ())
            {
              BundleDeletion (bundle, CUSTODY_BLOCK_UNINTELLIGIBLE);
              return;          
            }
          else if (block->IsDiscardBlock ())
            {
              CanonicalBundleHeader header = *block;
              tmp.push_back (header);
            }
          else 
            {
              block->SetForwarded (true);
            }
        }
    }
  
  bundle->SetCanonicalHeaders (canonicalBlocks);

  // Step 4:
  if (bundle->IsCustodyTransferRequested ())
    {
      if (m_bundleRouter->HasBundle (bundle))
        {
          Ptr<Bundle> otherBundle = m_bundleRouter->GetBundle (bundle);
          
          
          if (otherBundle != 0 && otherBundle->HasRetentionConstraint (RC_CUSTODY_ACCEPTED))
            {
              GenerateCustodySignal (bundle, CUSTODY_REDUNDANT_RECEPTION, false);
              bundle->RemoveRetentionConstraint (RC_DISPATCH_PENDING);
 
              //Simulator::ScheduleNow (&BundleProtocolAgent::BundleDeletion, this, bundle, CUSTODY_REDUNDANT_RECEPTION);
              return;
            }
        }
    }
   // Step 5:
  BundleDispatching (bundle);
 }      


bool 
BundleProtocolAgent::CanProcessBlock (const BlockType& block)
{
  //NS_LOG_DEBUG ( "(" << m_node->GetId () << ") " << "BundleProtocolAgent::CanProcessBlock");
  return block == PAYLOAD_BLOCK || m_bundleRouter->IsRouterSpecific (block);
}

// 5.7 Local Bundle Delivery
void
BundleProtocolAgent::LocalBundleDelivery (Ptr<Bundle> bundle)
{
  // Step 1: No bundle fragmentation implemented making this step, unnecessary

  // Step 2: Registration always in active state
  ForwardUp (bundle);

  // Step 3:
  if (bundle->GetReportBundleDelivery ())
    {
      // Generate a bundle delivery status report
    }
  
  if (bundle->IsCustodyTransferRequested ())
    {
      GenerateCustodySignal (bundle, true);
    }
}

void
BundleProtocolAgent::ForwardUp (Ptr<Bundle> bundle)
{
  m_deliveryLogger (bundle);
  BundleEndpointId address = bundle->GetSourceEndpoint ();
  Endpoints endpoints = m_registrationManager->Lookup (bundle->GetDestinationEndpoint ());
  Ptr<Packet> adu = bundle->GetPayload (); 
  for (EndpointsI endpoint = endpoints.begin (); endpoint != endpoints.end (); ++endpoint)
    {
      (*endpoint)->ForwardUp (adu->Copy (), address);
    }
  m_bundleRouter->BundleDelivered (bundle, false);
}

// 5.10.1 Custody Acceptance
void
BundleProtocolAgent::CustodyAcceptance (Ptr<Bundle> bundle)
{
  bundle->AddRetentionConstraint (RC_CUSTODY_ACCEPTED);
  
  if (bundle->GetPrimaryHeader().GetReportCustodyAcceptance ())
    {
      // Generate a custody acceptance report 
    }
  
  GenerateCustodySignal (bundle, true);
  
  bundle->SetCustodianEndpoint (m_eid);

  m_bundleRouter->HandleCustodyAcceptance (bundle);
}

// 5.10.2 Custody Release
void
BundleProtocolAgent::CustodyRelease (Ptr<Bundle> bundle)
{
  //  bundle->RemoveRetentionConstraint (RC_CUSTODY_ACCEPTED);
  // Remove the custody transfer timer that has been established for this bundle
  
  m_bundleRouter->HandleCustodyRelease (bundle);
}

// 5.11 Custody Transfer Success
void 
BundleProtocolAgent::CustodyTransferSuccess (const CustodySignal& signal)
{
  GlobalBundleIdentifier gbid (signal.GetSourceBundleEndpointId (), signal.GetCreationTimestamp ());
  Ptr<Bundle> bundle = m_bundleRouter->GetBundle (gbid);

  if (bundle == 0)
    return;

  CustodyRelease (bundle);
}

// 5.12 Custody Transfer Failed
void
BundleProtocolAgent::CustodyTransferFailure (const CustodySignal& signal, bool timeout)
{
  m_bundleRouter->HandleCustodyTransferFailure (signal,timeout);
}

// 5.13 Bundle Deletion
void 
BundleProtocolAgent::BundleDeletion (Ptr<Bundle> bundle, const CustodySignalReason& reason)
{
  // Step 1:
  if (bundle->HasRetentionConstraint (RC_CUSTODY_ACCEPTED))
    {
      CustodyRelease (bundle);
      // Generate bundle deletion status report citing the reason for the deletion.
    }
  else if (bundle->GetReportBundleDeletion ())
    {
      // Generate a bundle deletion status report
    }

  // Step 2:
  bundle->RemoveAllRetentionConstraints ();
  m_bundleRouter->DeleteBundle (bundle,true);
}

// 6.3 Reception of Custody Signal
void 
BundleProtocolAgent::CustodySignalReception (const CustodySignal& signal)
{
  if (signal.GetCustodyTransferSucceeded ())
    {
      CustodyTransferSuccess (signal);
    }
  else 
    {
      CustodyTransferFailure (signal, false);
    }
}


void
BundleProtocolAgent::SendBundle (Ptr<Link> link, Ptr<Bundle> bundle)
{
  Simulator::ScheduleNow (&ConvergenceLayerAgent::BundleQueued, m_cla, link, bundle);
}

Ptr<Registration>
BundleProtocolAgent::CreateRegistration (void) 
{
  Ptr<Registration> registration = CreateObject<Registration> ();
  registration->SetBundleProtocol (this);
  return registration;
}

RegistrationEndpoint*
BundleProtocolAgent::Allocate ()
{
  return m_registrationManager->Allocate (m_eid);
}

RegistrationEndpoint*
BundleProtocolAgent::Allocate (const BundleEndpointId& eid)
{
  return m_registrationManager->Allocate (eid);
}

void
BundleProtocolAgent::DeAllocate (RegistrationEndpoint *regEndpoint)
{
  m_registrationManager->DeAllocate (regEndpoint);
}

}} // namespace bundleProtocol, ns3
