/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */

#include "ns3/simulator.h"
#include "ns3/log.h"
#include "ns3/random-variable.h"
#include "ns3/packet-socket-address.h"
#include "ns3/packet-socket-factory.h"
#include "ns3/packet.h"
#include "ns3/boolean.h"
#include "ns3/uinteger.h"
#include "ns3/trace-source-accessor.h"
#include "bp-neighbourhood-detection-agent.h"
#include "ns3/mobility-model.h"

// FIXME st�ll in jittret till ett bra v�rde
#define HELLO_MAX_JITTER (m_helloIntervall.GetSeconds() / 5)
#define JITTER (Seconds (UniformVariable ().GetValue (0, HELLO_MAX_JITTER)))

namespace ns3 {
namespace bundleProtocol {

NS_LOG_COMPONENT_DEFINE ("NeighbourhoodDetectionAgent");

NS_OBJECT_ENSURE_REGISTERED (HelloHeader);
  
HelloHeader::HelloHeader ()
  : m_eid (BundleEndpointId::GetAnyBundleEndpointId ())
{}
  
HelloHeader::~HelloHeader ()
{}

void
HelloHeader::SetBundleEndpointId (BundleEndpointId eid)
{
  m_eid = eid;
}

BundleEndpointId
HelloHeader::GetBundleEndpointId () const
{
  return m_eid;
}
  
TypeId
HelloHeader::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::bundleProtocol::HelloHeader")
    .SetParent<Header> ()
    .AddConstructor<HelloHeader> ()
    ;
  return tid;
}

TypeId
HelloHeader::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}

void
HelloHeader::Print (std::ostream &os) const
{
  os << "HelloHeader: eid = " << m_eid; 
}

uint32_t
HelloHeader::GetSerializedSize (void) const
{
  return m_eid.GetSerializedSize () + 4;
}

void
HelloHeader::Serialize (Buffer::Iterator start) const
{
  int length = m_eid.GetSerializedSize (); 
  Buffer::Iterator i = start;
  i.WriteHtonU32 (length);
  uint8_t buf [length];
  m_eid.Serialize (buf);
  i.Write (buf, length);
}

uint32_t
HelloHeader::Deserialize (Buffer::Iterator start)
{
  Buffer::Iterator i = start;
  uint32_t length = i.ReadNtohU32 (); 
  uint8_t buf [length];
  i.Read (buf,length);
  m_eid = BundleEndpointId::Deserialize (buf);
  return GetSerializedSize ();
}

// --------------- HELLO AGENT ----------------------------------
NS_OBJECT_ENSURE_REGISTERED (NeighbourhoodDetectionAgent);

TypeId
NeighbourhoodDetectionAgent::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::bundleProtocol::NeighbourhoodDetectionAgent")
    .SetParent<Object> ()
    .AddConstructor<NeighbourhoodDetectionAgent> ()
    .AddAttribute ("BundleEndpointId",
                   "Sets the bundle endpoint id.",
                   BundleEndpointIdValue (BundleEndpointId ()),
                   MakeBundleEndpointIdAccessor (&NeighbourhoodDetectionAgent::m_eid),
                   MakeBundleEndpointIdChecker ())
    .AddAttribute ("HelloIntervall",
                   "Sets the intervall between hello broadcasts",
                   TimeValue (Time (Seconds (20))),
                   MakeTimeAccessor (&NeighbourhoodDetectionAgent::m_helloIntervall),
                   MakeTimeChecker ())
    .AddTraceSource ("SendHello", "A hello message has been broadcasted.",
                     MakeTraceSourceAccessor (&NeighbourhoodDetectionAgent::m_sendLogger))
    .AddTraceSource ("ReceivedHello", "A hello message has been received.",
                     MakeTraceSourceAccessor (&NeighbourhoodDetectionAgent::m_receiveLogger))
    ;
  return tid;
}

NeighbourhoodDetectionAgent::NeighbourhoodDetectionAgent ()
  : m_node (0), 
    m_device (0),
    m_helloTimer (Timer::CANCEL_ON_DESTROY),
    m_started (false)
{
  m_helloTimer.SetFunction (&NeighbourhoodDetectionAgent::HelloTimerExpire, this);
}

NeighbourhoodDetectionAgent::NeighbourhoodDetectionAgent (Ptr<Node> node, 
                        Ptr<NetDevice> device, 
                        BundleEndpointId eid)
  : 
  m_node (node),
  m_device (device),
  m_eid (eid), 
  m_helloTimer (Timer::CANCEL_ON_DESTROY),
  m_started (false)
{
  m_helloTimer.SetFunction (&NeighbourhoodDetectionAgent::HelloTimerExpire, this);
}

NeighbourhoodDetectionAgent::~NeighbourhoodDetectionAgent ()
{}

void
NeighbourhoodDetectionAgent::DoDispose ()
{
  m_node = 0;
  m_device = 0;
  m_socket = 0;
  m_discoveredLinkCb = MakeNullCallback<void, Ptr<Packet>, Address > ();
  Object::DoDispose ();
}
 
void 
NeighbourhoodDetectionAgent::SetNode (Ptr<Node> node)
{
  m_node = node;
}

void
NeighbourhoodDetectionAgent::SetNetDevice (Ptr<NetDevice> device)
{
  m_device = device;
}

Ptr<NetDevice> 
NeighbourhoodDetectionAgent::GetDevice () const
{
  return m_device;
}

void
NeighbourhoodDetectionAgent::SetBundleEndpointId (BundleEndpointId eid)
{
  m_eid = eid;
}

BundleEndpointId
NeighbourhoodDetectionAgent::GetBundleEndpointId () const
{
  return m_eid;
}

Time
NeighbourhoodDetectionAgent::GetHelloIntervall () const
{
  return m_helloIntervall;
}

void
NeighbourhoodDetectionAgent::SetDiscoveredLinkCallback (Callback<void, Ptr<Packet>, Address > discoveredLinkCb)
{
  m_discoveredLinkCb = discoveredLinkCb;
 
}

void
NeighbourhoodDetectionAgent::Init ()
{
  NS_LOG_DEBUG ("(" << m_node->GetId () << ")" << "NeighbourhoodDetectionAgent::Start");
  if (m_socket == 0)
    {
      NS_ASSERT (m_node != 0 && m_device != 0 && m_eid != BundleEndpointId ());
      // Setup the socket
      PacketSocketAddress sendAddr;
      sendAddr.SetSingleDevice (m_device->GetIfIndex ());
      sendAddr.SetPhysicalAddress  (m_device->GetBroadcast ());
      sendAddr.SetProtocol (140);
      m_socket = Socket::CreateSocket (m_node, PacketSocketFactory::GetTypeId ());
      NS_ASSERT (m_socket != 0);
      m_socket->Bind (sendAddr);
      m_socket->Connect (sendAddr);
      m_socket->SetRecvCallback (MakeCallback (&NeighbourhoodDetectionAgent::HandleHello, this));
    }
}

void
NeighbourhoodDetectionAgent::Start ()
{
  if (!m_started)
    {
      m_started = true;
      m_helloTimer.Schedule (JITTER);
    }
}

void 
NeighbourhoodDetectionAgent::Stop ()
{
  NS_LOG_DEBUG ("(" << m_node->GetId () << ")" << "NeighbourhoodDetectionAgent::Stop");
  if (m_started)
    {
      m_started = false;
      m_helloTimer.Remove ();
    }
}

void
NeighbourhoodDetectionAgent::HelloTimerExpire ()
{
  //NS_LOG_DEBUG ("(" << m_node->GetId () << ")" << "NeighbourhoodDetectionAgent:::HelloTimerExpire");
  SendHello ();
  m_helloTimer.Schedule (m_helloIntervall-JITTER);
}

void
NeighbourhoodDetectionAgent::SendHello ()
{
  Ptr<MobilityModel> mm = m_node->GetObject<MobilityModel> ();
  NS_LOG_DEBUG ("(" << m_node->GetId () << ") " <<"############################# " <<  "NeighbourhoodDetectionAgent::SendHello" << "(" << mm->GetPosition () << ")");
  //cout << Simulator::Now ().GetSeconds () << " (" << m_node->GetId () << ") " <<"############################# " <<  "NeighbourhoodDetectionAgent::SendHello" << "(" << mm->GetPosition () << ")" << endl;
  HelloHeader header;
  header.SetBundleEndpointId (m_eid);
  Ptr<Packet> hello = Create<Packet> ();
  hello->AddHeader (header);
  m_socket->Send (hello);
  m_sendLogger (hello);
}

void
NeighbourhoodDetectionAgent::HandleHello (Ptr<Socket> socket)
{
  Ptr<Packet> receivedHello;
  Address fromAddress;
  receivedHello = socket->RecvFrom (fromAddress);

  m_receiveLogger (receivedHello);

  HelloHeader header;
  receivedHello->PeekHeader (header);

  Ptr<MobilityModel> mm = m_node->GetObject<MobilityModel> (); 
  NS_LOG_DEBUG ("(" << m_node->GetId () << ") " <<"############################# " <<  "NeighbourhoodDetectionAgent::HandleHello from endpoint id " << header.GetBundleEndpointId ()  << " size = " << receivedHello->GetSize () <<  " (" << mm->GetPosition () << ")");
  //cout << Simulator::Now ().GetSeconds () << " (" << m_node->GetId () << ") " <<"############################# " <<  "NeighbourhoodDetectionAgent::HandleHello from endpoint id " << header.GetBundleEndpointId ()  << " size = " << receivedHello->GetSize () <<  " (" << mm->GetPosition () << ")" << endl;
  Simulator::ScheduleNow (&NeighbourhoodDetectionAgent::NotifyDiscoveredLink, this, receivedHello, fromAddress);
}

void
NeighbourhoodDetectionAgent::NotifyDiscoveredLink (Ptr<Packet> hello, Address fromAddress)
{
  if (!m_discoveredLinkCb.IsNull ())
    m_discoveredLinkCb (hello, fromAddress);    
}

}} // namespace bundleProtocol, ns3
