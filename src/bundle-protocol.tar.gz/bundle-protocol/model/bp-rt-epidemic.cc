/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Author: Sérgio Vieira
 * MACC - Mestrado Acadêmico em Ciência da Computação - 2012
 */
#include <cmath>
#include <algorithm>
#include <limits>
#include <sstream>
#include "ns3/log.h"
#include "ns3/uinteger.h"
#include "ns3/address.h"
#include "ns3/mac48-address.h"
#include "ns3/mobility-model.h"
#include "ns3/trace-source-accessor.h"
#include "ns3/nstime.h"
#include "ns3/boolean.h"
#include "bp-rt-epidemic.h"
#include "bp-header.h"
#include "bp-orwar-contact.h"
#include "bp-link-manager.h"
#include "bp-orwar-link-manager.h"
#include "bp-neighbourhood-detection-agent.h"
#include "bp-link.h"
NS_LOG_COMPONENT_DEFINE ("RTEpidemic");

namespace ns3 {
namespace bundleProtocol {

NS_OBJECT_ENSURE_REGISTERED (RTEpidemic);

TypeId RTEpidemic::GetTypeId(void) {
	static TypeId
		tid = TypeId ("ns3::bundleProtocol::RTEpidemic")
		.SetParent<BundleRouter>()
		.AddConstructor<RTEpidemic>();
	return tid;
}

RTEpidemic::RTEpidemic() : BundleRouter() {
	NS_LOG_DEBUG ("RTEpidemic::RTEpidemic() - constructor");
}

RTEpidemic::~RTEpidemic() {
	NS_LOG_DEBUG ("RTEpidemic::~RTEpidemic() - destructor");
}

void RTEpidemic::DoInit() {
	m_nda->Start(); // Ptr<NeighbourhoodDetectionAgent>
}

void RTEpidemic::DoDispose() {
	BundleRouter::DoDispose();
}

void
RTEpidemic::ReceiveRouterSpecific (Ptr<Bundle> bundle)
{

  //NS_LOG_DEBUG ("(" << m_node->GetId () << ") "  << "OrwarRouterChangedOrder::ReceiveRouterSpecific");
/*
	CanonicalBundleHeader header = bundle->GetCanonicalHeaders ().front ();

  switch (header.GetBlockType ())
    {
    case KNOWN_DELIVERED_MESSAGES_BLOCK:
      HandleKdm (bundle);
      break;
    case CONTACT_WINDOW_INFORMATION_BLOCK:
      HandleCwi (bundle);
      break;
    default:
      //cout << Doh this should not happen!! :/";
      break;
    }
 */
}

void
RTEpidemic::SentRouterSpecific (Ptr<Link> link, const GlobalBundleIdentifier& gbid)
{
  //NS_LOG_DEBUG ("(" << m_node->GetId () << ") "  << "OrwarRouterChangedOrder::SentRouterSpecific");
  //cout << Simulator::Now ().GetSeconds () << "(" << m_node->GetId () << ") "  << "OrwarRouterChangedOrder::SentRouterSpecific" << endl;
/*
  Ptr<Bundle> bundle = GetBundle (gbid);

  if (bundle != 0)
    {
      RemoveRouterSpecificBundle (bundle,0);
      CanonicalBundleHeader header = bundle->GetCanonicalHeaders ().front ();
      /*
      switch (header.GetBlockType ())
        {
        case KNOWN_DELIVERED_MESSAGES_BLOCK:
          SentKdm (link);
          break;
        case CONTACT_WINDOW_INFORMATION_BLOCK:
          SentCwi (link);
          break;
        default:
          break;
        }
    }
  else
    {
     // Simulator::ScheduleNow (&OrwarRouterChangedOrder::TryToStartSending, this);
    }
    */
}

void
RTEpidemic::DoLinkClosed (Ptr<Link> link)
{
  /*
  if (m_node->GetId () == 49 && link->GetRemoteEndpointId ().GetId () == 21)
    cout << Simulator::Now ().GetSeconds () << " (" << m_node->GetId () << ")" << "OrwarRouterChangedOrder::DoLinkClosed" << endl;
  */
/*
  if (link->GetContact () != 0)
    {
      Ptr<OrwarContact> oc (dynamic_cast<OrwarContact *> (PeekPointer (link->GetContact ())));

      if (oc->GetState () != READY)
        {
          //m_contactSetupFailedLogger (1);
        }

      BundleList bundles = link->GetContact ()->GetQueuedBundles ();
      for (BundleList::iterator iter = bundles.begin (); iter != bundles.end (); ++iter)
        {
          link->GetContact ()->DequeueBundle (*iter);
          /*
          if (m_node->GetId () == 49 && link->GetRemoteEndpointId ().GetId () == 21)
            {
              cout << Simulator::Now ().GetSeconds () << " (" << m_node->GetId () << ")" << "CancelTransmission anropas av DoLinkClosed" << endl;
            }

          CancelTransmission (*iter, link);
        }
    }

  RemoveRouterSpecificBundles (link);
  */
}

void
RTEpidemic::RemoveRouterSpecificBundles (Ptr<Link> link)
{
	/*
  BundleList tmp;
  for (BundleList::iterator iter = m_routerSpecificList.begin (); iter != m_routerSpecificList.end (); ++iter)
    {
      if (link->GetRemoteEndpointId () == (*iter)->GetDestinationEndpoint ())
        {
          tmp.push_back (*iter);
        }
    }
  for (BundleList::iterator iter = tmp.begin (); iter != tmp.end (); ++iter)
    {
      RemoveRouterSpecificBundle (*iter, 1);
    }
    */
}

Ptr<Link>
RTEpidemic::DoCreateLink (const BundleEndpointId& eid, const Address& address)
{
  //NS_LOG_DEBUG ("(" << m_node->GetId () << ") "  << "OrwarRouterChangedOrder::DoCreateLink");
/*
Ptr<ConvergenceLayerAgent> cla = m_node->GetObject<BundleProtocolAgent> ()->GetConvergenceLayerAgent ();
  Ptr<Link> link = CreateObject<Link> ();

  link->SetLinkLostCallback (MakeCallback (&ConvergenceLayerAgent::LinkLost, cla));
  link->SetHackFixmeCallback (MakeCallback (&ConvergenceLayerAgent::HackFixme, cla));


  Ptr<OrwarLinkManager> olm (dynamic_cast<OrwarLinkManager *> (PeekPointer (m_linkManager)));
  link->m_expirationTimer.SetFunction (&OrwarLinkManager::CheckIfExpired, olm);
  link->m_expirationTimer.SetArguments (link);

  link->SetRemoteEndpointId (eid);
  link->SetRemoteAddress (address);
  */
	Ptr<Link> link = CreateObject<Link> ();

	return link;
}



void
RTEpidemic::AddRouterSpecificBundle (Ptr<Bundle> bundle)
{
  //NS_LOG_DEBUG ("(" << m_node->GetId () << ") "  << "OrwarRouterChangedOrder::AddRouterSpecificBundle");
  //cout << Simulator::Now ().GetSeconds () << " (" << m_node->GetId () << ") "  << "OrwarRouterChangedOrder::AddRouterSpecificBundle" << endl;
  m_routerSpecificList.push_back (bundle);
  //cout << "(" << m_node->GetId () << ") " << "======== TryToStartSending anropat fr�n AddRouterSpecific ========" << endl;
  //Simulator::ScheduleNow (&OrwarRouterChangedOrder::TryToStartSending, this);
}
void RTEpidemic::DoLinkDiscovered(Ptr<Link> link) {
	//m_contactOppLogger(1);
	//m_contactOppBetweenLogger(m_node->GetId(), link->GetRemoteEndpointId().GetId());
	m_linkManager->OpenLink(link);

	/*
	Ptr<Contact> oc = dynamic_cast<Contact *> (PeekPointer(link->GetContact()));
	oc->ChangeState(S_CREATED);
	// Want to send my Kdm to the other node.
	Simulator::ScheduleNow(&RTEpidemic::SendCwi, this, link, true);
	*/
}

void RTEpidemic::DoBundleReceived(Ptr<Bundle> bundle) {
	Ptr<Link> link = m_linkManager->FindLink(bundle->GetReceivedFrom().front().GetEndpoint());
	if (link != 0) {
		link->UpdateLastHeardFrom();
	}
}

Ptr<Bundle> RTEpidemic::DoSendBundle(Ptr<Link> link, Ptr<Bundle> bundle) {
	link->GetContact()->EnqueueBundle(bundle);

	Ptr<Bundle> send = bundle->Copy();
	/*
	if (!IsRouterSpecific(bundle)) {
		if (bundle->GetReplicationFactor() > 1) {
			send->SetReplicationFactor(ceil((double) bundle->GetReplicationFactor() / 2.0));
		}
	}
	*/
	return send;
}

void RTEpidemic::DoBundleSent(const Address& address, const GlobalBundleIdentifier& gbid, bool finalDelivery) {
	NS_LOG_DEBUG ("(" << m_node->GetId () << ") " << "RTEpidemic::DoBundleSent");

	Mac48Address mac = Mac48Address::ConvertFrom(address);
	Ptr<Link> link = m_linkManager->FindLink(mac);

	Ptr<Bundle> bundle = GetBundle(gbid);

	if (bundle != 0) {
		link->UpdateLastHeardFrom();

		if (link->GetState() == LINK_CONNECTED || link->GetState() == LINK_PAUSED) {
			link->GetContact()->DequeueBundle(gbid);
			link->GetContact()->ResetRetransmissions();
		}

		if (IsRouterSpecific(bundle)) {
			SentRouterSpecific(link, bundle);
		} else {
			m_forwardLog.AddEntry(bundle, link);
			if (finalDelivery) {
				BundleDelivered(bundle, true);
			} else {
				bundle->SetReplicationFactor(floor(
						(double) bundle->GetReplicationFactor() / 2.0));
			}
			//Simulator::ScheduleNow(&RTEpidemic::TryToStartSending, this);
		}
	} else {
		// FIXME: Hmm hur ska man ta hand om det h�r fallet...
		// H�r vet jag enbbart gbid, men vet ej vilken typ av bundle det �r
		// eller vad den har f�r ttl.
		if (finalDelivery) {
			// This is a ugly hack utilitzing the fact that i know that
			// the ttl is "inifinite".
			Ptr<Bundle> bundle = Create<Bundle> ();
			bundle->SetSourceEndpoint(gbid.GetSourceEid());
			bundle->SetCreationTimestamp(gbid.GetCreationTimestamp());
			bundle->SetLifetime(43000);
			BundleDelivered(bundle, true);
			//Simulator::ScheduleNow(&RTEpidemic::TryToStartSending, this);
		}

	}
}

void RTEpidemic::DoBundleTransmissionFailed(const Address& address,
		const GlobalBundleIdentifier& gbid) {
	NS_LOG_DEBUG ("(" << m_node->GetId () << ") " << "RTEpidemic::DoBundleTransmissionFailed");
	Mac48Address mac = Mac48Address::ConvertFrom(address);
	Ptr<Link> link = m_linkManager->FindLink(mac);
	if (link->GetContact() != 0) {
		//link->GetContact ()->DequeueBundle (gbid);
	}

	//PauseLink(link);
}

bool RTEpidemic::DoAcceptBundle(Ptr<Bundle> bundle, bool fromApplication) {
	if (HasBundle(bundle)) {
		//m_redundantRelayLogger(bundle);
		Ptr<Bundle> otherBundle = GetBundle(bundle->GetBundleId());
		otherBundle->AddReceivedFrom(bundle->GetReceivedFrom().front());
		return false;
	}
	return CanMakeRoomForBundle(bundle);
}

bool RTEpidemic::DoCanDeleteBundle(const GlobalBundleIdentifier& gbid) {
	return true;
}

void RTEpidemic::DoInsert(Ptr<Bundle> bundle) {
	// This is my extra thing, i always set the eid to current node holding the bundle.
	bundle->SetCustodianEndpoint(m_eid);

	m_bundleList.push_back(bundle);
	//sort(m_bundleList.begin(), m_bundleList.end(), UtilityPerBitCompare());

	// If this is the first bundle, I now want to begin sending hello messages announcing that
	// I have something to send. If there is more than one bundle in the queue this means that
	// I already have started sending hello messages.
	//if (m_nBundles == 1 && !m_alwaysSendHello) {
	if (m_nBundles == 1) {
		m_nda->Start();
	}

	//Simulator::ScheduleNow(&RTEpidemic::TryToStartSending, this);
}

bool RTEpidemic::CanMakeRoomForBundle(Ptr<Bundle> bundle) {
	if (bundle->GetSize() < m_maxBytes) {
		return true;
	} else {
		return false;
	}

}



bool RTEpidemic::MakeRoomForBundle(Ptr<Bundle> bundle) {
	if (bundle->GetSize() < m_maxBytes) {
		if (bundle->GetSize() < GetFreeBytes()) {
			return true;
		}

		for (BundleList::reverse_iterator iter = m_bundleList.rbegin(); iter
				!= m_bundleList.rend();) {
			Ptr<Bundle> currentBundle = *(iter++);

			DeleteBundle(currentBundle, true);
			if (bundle->GetSize() < GetFreeBytes()) {
				return true;
			}
		}
	}

	return false;
}

bool RTEpidemic::DoDelete(const GlobalBundleIdentifier& gbid, bool drop) {
	// If this is the last bundle in the queue, stop sending Hello messages.
	//if (m_nBundles == 1 && !m_alwaysSendHello) {
	if (m_nBundles == 1 ) {
		m_nda->Stop();
	}
	return BundleRouter::DoDelete(gbid, drop);
}

void RTEpidemic::DoCancelTransmission(Ptr<Bundle> bundle, Ptr<Link> link) {
	/*
	 if (m_node->GetId () == 49)
	 {
	 cout << Simulator::Now ().GetSeconds () << " (" << m_node->GetId () << ")" << "DoCancelTransmission anropas p� bundlen" << endl;
	 cout << *bundle << endl;
	 }
	 */
	//NS_LOG_DEBUG ("(" << m_node->GetId () << ") "  << "RTEpidemic::DoCancelTransmission");
}

void RTEpidemic::DoTransmissionCancelled(const Address& address,
		const GlobalBundleIdentifier& gbid) {
	Mac48Address mac = Mac48Address::ConvertFrom(address);
	Ptr<Link> link = m_linkManager->FindLink(mac);

	if (link == 0) {
		cout << "This would just be strange" << endl;
	}
	link->GetContact()->DequeueBundle(gbid);

	//Simulator::ScheduleNow(&RTEpidemic::TryToStartSending, this);
}

uint8_t RTEpidemic::DoCalculateReplicationFactor(const BundlePriority& priority) const {
	//NS_LOG_DEBUG ("(" << m_node->GetId () << ") "  << "RTEpidemic::DoCalculateReplicationFactor");
	/*
	switch (priority) {
	case BULK:
		return m_replicationFactor - m_deltaReplicationFactor;
		break;
	case NORMAL:
		return m_replicationFactor;
		break;
	case EXPEDITED:
		return m_replicationFactor + m_deltaReplicationFactor;
		break;
	default:
		return 1;
	}
	*/
	return 1;
}
void
RTEpidemic::SendRouterSpecific (Ptr<Link> link, Ptr<Bundle> bundle)
{
  //NS_LOG_DEBUG ("(" << m_node->GetId () << ") "  << "OrwarRouterChangedOrder::SendRouterSpecific");
}

void RTEpidemic::DoBundleDelivered (Ptr<Bundle> bundle, bool fromAck)
{
  NS_LOG_DEBUG ("############################# " << "(" << m_node->GetId () << ") "  << "OrwarRouterChangedOrder::DoBundleDelivered");
  //cout << Simulator::Now ().GetSeconds () << " (" << m_node->GetId () << ") ############################# " << "OrwarRouterChangedOrder::DoBundleDelivered" << endl;
  /*
  m_kdm.Insert (bundle);
  if (fromAck)
    {
      RemoveDeliveredBundles (m_kdm);
    }
  */
}

bool
RTEpidemic::DoIsRouterSpecific (Ptr<Bundle> bundle)
{
  //NS_LOG_DEBUG ("(" << m_node->GetId () << ") "  << "OrwarRouterChangedOrder::DoIsRouterSpecific");
  CanonicalBundleHeader header = bundle->GetCanonicalHeaders ().front ();
  return IsRouterSpecific (header.GetBlockType ());
}

bool
RTEpidemic::DoIsRouterSpecific (const BlockType& block)
{
  switch (block)
    {
    case KNOWN_DELIVERED_MESSAGES_BLOCK:
    case CONTACT_WINDOW_INFORMATION_BLOCK:
      return true;
      break;
    default:
      break;
    }
  return false;
}

Ptr<Bundle>
RTEpidemic::GetRouterSpecificBundle (const GlobalBundleIdentifier& gbid)
{
  //NS_LOG_DEBUG' ("(" << m_node->GetId () << ") "  << "OrwarRouterChangedOrder::GetRouterSpecificBundle");
  BundleList::iterator iter = find_if (m_routerSpecificList.begin (), m_routerSpecificList.end (), MatchingGbid (gbid));

  if (iter != m_routerSpecificList.end ())
    {
      return *iter;
    }
  else
    {
      return 0;
    }
}

bool
RTEpidemic::HasRouterSpecificBundle (const GlobalBundleIdentifier& gbid)
{
  //NS_LOG_DEBUG' ("(" << m_node->GetId () << ") "  << "OrwarRouterChangedOrder::HasRouterSpecificBundle");
  return find_if (m_routerSpecificList.begin (), m_routerSpecificList.end (), MatchingGbid (gbid)) != m_routerSpecificList.end ();
}


void
RTEpidemic::RemoveRouterSpecificBundle (const GlobalBundleIdentifier& gbid, uint8_t reason)
{
  Ptr<Bundle> bundle = GetRouterSpecificBundle (gbid);
  if (bundle != 0)
    {
     // m_routerDeleteLogger (bundle, reason);
    }
  //NS_LOG_DEBUG ("(" << m_node->GetId () << ") "  << "OrwarRouterChangedOrder::RemoveRouterSpecificBundle");
  //cout << Simulator::Now ().GetSeconds () << " (" << m_node->GetId () << ") "  << "OrwarRouterChangedOrder::RemoveRouterSpecificBundle" << endl;
  BundleList::iterator iter = remove_if (m_routerSpecificList.begin (), m_routerSpecificList.end (), MatchingGbid (gbid));

  if (iter != m_routerSpecificList.end ())
    {
      m_routerSpecificList.erase (iter, m_routerSpecificList.end ());
    }
}

}
} // namespace bundleProtocol, ns3
